import sys
import os
import re
import json
import urllib.request
import urllib.parse
import firebase_admin
from firebase_admin import credentials, firestore

# تهيئة الفايربيس
SERVICE_KEY_FILE = 'serviceAccountKey.json'

if not os.path.exists(SERVICE_KEY_FILE):
    print(f"❌ ملف المفتاح [{SERVICE_KEY_FILE}] غير موجود بنفس المجلد!")
    sys.exit(1)

try:
    cred = credentials.Certificate(SERVICE_KEY_FILE)
    firebase_admin.initialize_app(cred)
    db = firestore.client()
except Exception as e:
    print(f"❌ خطأ في الاتصال بالفايربيس: {e}")
    sys.exit(1)

def fetch_page(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"❌ خطأ بالوصول للرابط: {e}")
        return None

def clean_chapter_name(text):
    match = re.search(r'(?:الفصل|chapter)\s*(\d+(?:\.\d+)?)', text, re.IGNORECASE)
    return f"الفصل {match.group(1)}" if match else text.strip()

def process_chapter(manga_ref, ch_title, ch_url):
    html = fetch_page(ch_url)
    if not html:
        return
    
    # استخراج الصور باستخدام Regex بدون حاجتنا لـ BeautifulSoup
    images = re.findall(r'<img[^>]+(?:data-src|src)=["\']([^"\']+)["\']', html, re.IGNORECASE)
    images = [i.strip() for i in images if i and 'logo' not in i.lower() and 'avatar' not in i.lower()]
    
    if images:
        doc_id = re.sub(r'[^a-zA-Z0-9]', '_', ch_title)
        manga_ref.collection('chapters').document(doc_id).set({
            'title': ch_title,
            'images': images,
            'url': ch_url,
            'updated_at': firestore.SERVER_TIMESTAMP
        }, merge=True)
        print(f"  └─ ✅ تم سحب: {ch_title} ({len(images)} صورة)")

def scrape_url(url):
    print(f"\n🚀 جاري جلب الرابط: {url}")
    html = fetch_page(url)
    if not html:
        print("❌ تعذر الوصول لصفحة الرابط.")
        return

    # استخراج العنوان بـ Regex
    title_match = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL | re.IGNORECASE)
    if not title_match:
        print("❌ لم يتم العثور على اسم المانجا.")
        return

    manga_title = re.sub(r'<[^>]+>', '', title_match.group(1)).strip()
    doc_id = re.sub(r'[^a-zA-Z0-9_]', '_', manga_title)
    manga_ref = db.collection('manga').document(doc_id)

    manga_ref.set({
        'title': manga_title,
        'source_url': url,
        'updated_at': firestore.SERVER_TIMESTAMP
    }, merge=True)

    # استخراج روابط الفصول بـ Regex
    chapter_matches = re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', html, re.DOTALL | re.IGNORECASE)
    chapters = []
    for ch_url, ch_text in chapter_matches:
        clean_text = re.sub(r'<[^>]+>', '', ch_text).strip()
        if 'chapter' in ch_url.lower() or 'chapter' in clean_text.lower() or 'فصل' in clean_text.lower():
            chapters.append((clean_chapter_name(clean_text), ch_url))

    print(f"📦 تم العثور على {len(chapters)} فصل لـ [{manga_title}]. جاري التحميل...")

    for title, ch_url in chapters:
        process_chapter(manga_ref, title, ch_url)

    print(f"🎉 اكتمل سحب {manga_title} بنجاح!")

def clean_database():
    print("\n🧹 جاري فحص وتنظيف المكررات من قاعدة البيانات...")
    docs = list(db.collection('manga').stream())
    seen_keys = set()
    deleted = 0

    for doc in docs:
        data = doc.to_dict()
        clean_title = re.sub(r'[^a-zA-Z0-9أ-ي]', '', data.get('title', '')).lower()
        key = data.get('source_url') or clean_title

        if key in seen_keys:
            for c in doc.reference.collection('chapters').list_documents():
                c.delete()
            doc.reference.delete()
            deleted += 1
        else:
            if key:
                seen_keys.add(key)

    print(f"✅ اكتمل التنظيف! تم حذف {deleted} عمل مكرر.")

def main_menu():
    while True:
        print("\n" + "="*40)
        print("   🤖 سكريبت الموبايل لسحب وتنظيف المانجا")
        print("="*40)
        print("1. سحب رابط مانجا / فصل")
        print("2. تنظيف المكررات من القاعدة")
        print("3. خروج")
        
        choice = input("\nاختر رقم الإجراء (1-3): ").strip()
        
        if choice == '1':
            target_url = input("أدخل الرابط: ").strip()
            if target_url:
                scrape_url(target_url)
        elif choice == '2':
            clean_database()
        elif choice == '3':
            print("👋 في أمان الله!")
            break
        else:
            print("❌ خيار غير صحيح.")

if __name__ == "__main__":
    main_menu()
